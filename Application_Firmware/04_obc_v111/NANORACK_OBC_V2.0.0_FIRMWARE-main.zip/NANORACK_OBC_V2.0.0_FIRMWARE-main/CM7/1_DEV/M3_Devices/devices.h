#ifndef M3_DEVICES_DEVICES_H_
#define M3_DEVICES_DEVICES_H_

#include "I2C_RTC-RV3129/rtc_rv3129.h"
#include "SPI_FRAM/fram_spi.h"

#endif /* M3_DEVICES_DEVICES_H_ */
