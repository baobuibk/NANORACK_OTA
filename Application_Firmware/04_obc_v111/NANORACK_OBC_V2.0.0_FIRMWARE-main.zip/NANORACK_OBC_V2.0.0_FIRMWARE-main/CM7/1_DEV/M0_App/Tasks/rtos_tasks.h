/*
 * rtos_task.h
 *
 *  Created on: Feb 21, 2025
 *      Author: CAO HIEU
 */

#ifndef APP_RTOS_TASK_RTOS_TASK_H_
#define APP_RTOS_TASK_RTOS_TASK_H_
#include "utils.h"

void OBC_RootGrowUp(void);

#endif /* APP_RTOS_TASK_RTOS_TASK_H_ */
