/*
 * rtos.h
 *
 *  Created on: Feb 21, 2025
 *      Author: CAO HIEU
 */

#ifndef APP_RTOS_RTOS_H_
#define APP_RTOS_RTOS_H_

void OBC_RTOS_Start(void);

#endif /* APP_RTOS_RTOS_H_ */
