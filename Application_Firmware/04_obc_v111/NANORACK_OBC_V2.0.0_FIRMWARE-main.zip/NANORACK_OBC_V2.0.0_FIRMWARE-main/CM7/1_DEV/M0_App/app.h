#ifndef M0_APP_APP_H_
#define M0_APP_APP_H_

#include "management.h"

#endif /* M0_APP_APP_H_ */
