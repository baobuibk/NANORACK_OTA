#include "ff.h"
#if FF_USE_LFN != 0

#if FF_CODE_PAGE == 949	/* Korean */

#else					/* Single Byte Character-Set */
//#include "ccsbcs.c"
#endif

#endif
