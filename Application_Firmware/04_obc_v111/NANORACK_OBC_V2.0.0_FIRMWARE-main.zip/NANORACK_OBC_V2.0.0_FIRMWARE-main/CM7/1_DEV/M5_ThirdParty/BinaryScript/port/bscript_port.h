// bscript_port.h
#pragma once

#include <stdint.h>

uint32_t BScript_GetTick(void);
void     BScript_Delayms(uint32_t ms);
