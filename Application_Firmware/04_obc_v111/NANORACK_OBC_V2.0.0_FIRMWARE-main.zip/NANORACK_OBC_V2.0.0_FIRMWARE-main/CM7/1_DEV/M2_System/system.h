#ifndef M2_SYSTEM_SYSTEM_H_
#define M2_SYSTEM_SYSTEM_H_

#include "SysLog/syslog.h"


#endif /* M2_SYSTEM_SYSTEM_H_ */
