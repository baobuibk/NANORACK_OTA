/************************************************
 *  @file     : management4.h
 *  @date     : May 13, 2025
 *  @author   : CAO HIEU
 *-----------------------------------------------
 *  Description :
 *    [-]
 ************************************************/

#ifndef M0_APP4_MGMT4_MANAGEMENT4_H_
#define M0_APP4_MGMT4_MANAGEMENT4_H_

void Mgmt_HardwareSystemPreparing(void);
void Mgmt_SystemStart(void);

#endif /* M0_APP4_MGMT4_MANAGEMENT4_H_ */
