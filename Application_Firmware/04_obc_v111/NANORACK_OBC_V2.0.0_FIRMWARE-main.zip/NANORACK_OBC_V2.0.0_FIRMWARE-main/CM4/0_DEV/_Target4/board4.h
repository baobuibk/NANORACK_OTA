/************************************************
 *  @file     : board4.h
 *  @date     : May 11, 2025
 *  @author   : CAO HIEU
 *-----------------------------------------------
 *  Description :
 *    [-]
 ************************************************/

#ifndef TARGET4_BOARD4_H_
#define TARGET4_BOARD4_H_

#define UART_PORT					USART6


#endif /* TARGET4_BOARD4_H_ */
